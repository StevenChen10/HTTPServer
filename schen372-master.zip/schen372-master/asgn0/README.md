**FILES**:
1. Split.c - This program takes a delimiter character and replaces every delimiter character it sees with a newline, as well as handling errors if the user 
does not use proper usage for this program to work.
2. Makefile - Builds the program
3. Readme - Description of files, usage,  and some things I thought and did.

**Data structures**:
I guess a data structure that I used in my program is a buffer array. Storing each byte in a array of chars and then freeing the data
in the array when its done being written to stdout.

**Errors that I handle**
1. Multi-char delimiters should return errno 22
2. Not enough arguments should return ernno 22
3. Invalid file should return errno 2
4. Permission Denied should return errno 13
5. File is a directory should return errno 21.

**Description of program**:
First off, the program checks if there are enough arguments given using ./split <char> <file1> <file2> ..., aswell as if the user is not giving
the program a multi-char delimiter. If not, then the program loops through the file part of **argv which starts at 2 since argv[0] holds the executable, and
argv[1] holds the delimiter. It then opens up the file in read only. If one of the arguments is '-' then fd is set to 0 which is a macro for stdin. If the
file does not exist in **argv, then the program warns the user that the file does not exist, aswell as sets errNum to errno. If everything is as normal, then
the program dynamically allocates 1024 bytes of memory and initialize them to 0. We then dereference argv[1] and store it in a char. Then, we loop through the file
and feed 1024 bytes from the file into the buffer continiously until we reach EOF. In the loop we would check each buffer element and check if it matches the delim char,
if so then we would modify the buffer[i] and replace it with a '\n'. Once we reach EOF, we exit the loop and write the buffer to stdout, aswell as free the buffer and close
the file, so we do not encounter any memory leaks. Lastly, we would return the errNum.

**
**USAGE**:
To use this program: 
1. Type `make` or `make all` or `make split` in terminal
2. Type `./split <char> <file_1> <file_2>` ... to split the file using a delimiter
3. If you want to get input from stdin you would have any <file_#> be set to '-' (without the apostrophes).
4. If you want to get out of stdin you would use the command `CTRL + D`.
5. If you want to delete any object or executable binary files type `make clean`

**DESIGN of program**:

I never took 13S so this assignment was definitely a refresher on my C knowledge. Some things that were vague were definitely what
some error codes we had to match with the /resources binary, as well as the pipeline tests. Originally, I was using read and write wrong before
I throughly gave the manpages a good read, aswell as an if else conditional statement if the delimiter char was equal to '-', if not then it would read from the file desriptor that read() gave. That caused me fail the efficiency test (I believe test 15 is the efficiency test), so I set fd to zero if delimiter was equal to '-' which is the macro for stdin.  I think my solution to the assignment is reasonably efficient as it runs and checks through every byte at most once. 


**References**:
1. https://man7.org/linux/man-pages/man2/read.2.html
2. https://linux.die.net/man/3/warn
3. https://linux.die.net/man/3/read
