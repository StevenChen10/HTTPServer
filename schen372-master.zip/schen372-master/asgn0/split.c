#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <err.h>
#include <errno.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int rd; //read descriptor
    int errNum = 0; //
    if (argc <= 2) { //handling error when there are not enough arguments.
        fprintf(stderr, "%s", "Not enough arguments\n"); //error message
        fprintf(stdout, "%s",
            "usage: ./split: <split_char> [<file1> <file2> ...]\n"); //usage description.
        errNum = EINVAL; //err number 22
        return errNum; //exit the program with errno
    }
    if (argv[1] == NULL || strlen(argv[1]) > 2 || strlen(argv[1]) > 1) { //check
        fprintf(stderr, "Cannot handle multi-character splits: %s\n", argv[1]); //error message
        fprintf(stdout, "%s",
            "usage: ./split: <split_char> [<file1> <file2>...]\n"); //usage description
        errNum = EINVAL; //err number 22
        return errNum; //exit the program with errno
    }
    for (int i = 2; i < argc; i++) { //iterate through all of the files
        int fd = open(argv[i], O_RDONLY); //open the file in read only mode
        if (*argv[i] == '-' && strlen(argv[i]) == 1) { //check if '-' is used for stdin
            fd = 0; //set the file descriptor to 0 or stdin
        }
        if (fd == -1) { //condition if file does not exist
            // fprintf(stderr, "%s: %s: No such file or directory\n", argv[0], argv[i]); //error message
            warn("%s", argv[i]); //warn user that file does not exist
            errNum = errno; //set errNum to errno 2 file or directory does not exist
        }
        char *buffer
            = calloc(4096, sizeof(char)); //allocate memory for the buffer to be used for reading
        char delim = *argv[1];
        while (fd != -1
               && (rd = read(fd, buffer, 4096)) > 0) { //loop until the file is finished being read
            for (int i = 0; i < 4096; i++) { //loop until buffer[] is finished being read
                if (buffer[i] == delim) { //if delim char is found replace with '\n'
                    buffer[i] = '\n';
                }
            }
            write(1, buffer, rd); //write buffer to stdout
        }
        if (rd == -1) {
            warn("%s", argv[i]); //warn user that there is an error with directory
            errNum = errno;
        }
        free(buffer); //free the buffer
        close(fd); //close the file that is opened
    }
    return errNum; //return's the errno
}
