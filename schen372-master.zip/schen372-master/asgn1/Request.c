#include <regex.h>
#include <assert.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/stat.h>
#include "Request.h"
#include "Response.h"

struct HTTP_Request request;
void parse_request(char *buf, int connfd) { //checks if the request line is valid.
    char *expr = "(^[a-zA-Z]{1,8}) (/[a-zA-Z0-9_.]{1,19}) (HTTP/[0-9].[0-9]\r\n)";
    regex_t regex;
    int result = regcomp(&regex, expr, REG_EXTENDED);
    char *request_line = calloc(2048, sizeof(char));
    strcpy(request_line, buf);
    regmatch_t found[4];

    if (result < 0) {
    }

    result = regexec(&regex, request_line, 4, found, 0);
    if (result == REG_NOMATCH) {
        free(request_line);
        regfree(&regex);
        bad_request(connfd);
        // }
    } else {
        int start = found[1].rm_so;
        int end = found[1].rm_eo;

        snprintf(request.method, sizeof(request.method), "%.*s", end - start, request_line + start);

        int second_start = found[2].rm_so;
        int second_end = found[2].rm_eo;
        snprintf(request.uri, sizeof(request.uri), "%.*s", second_end - second_start,
            request_line + second_start);

        int third_start = found[3].rm_so;
        int third_end = found[3].rm_eo;
        snprintf(request.version, sizeof(request.version) + 1, "%.*s", third_end - third_start,
            request_line + third_start);
        int is_get = strcmp(request.method, "GET");
        int is_put = strcmp(request.method, "PUT");
        int is_append = strcmp(request.method, "APPEND");
        if (strstr(request.version, "HTTP/1.1") == NULL) {
            free(request_line);
            regfree(&regex);
            bad_request(connfd);
        } else if (is_get != 0 && is_put != 0 && is_append != 0) {
            free(request_line);
            regfree(&regex);
            not_implemented(connfd);
        } else {
            int end_of_request = found[0].rm_eo;
            char *end_of_request_line = calloc(2048, sizeof(char));
            snprintf(end_of_request_line, 4, "%s", request_line + end_of_request);
            char *check = strstr(end_of_request_line, "\r\n");
            if (check != NULL && strcmp(request.method, "GET") == 0) {
                free(end_of_request_line);
                free(request_line);
                regfree(&regex);
                check_request(connfd, request);
            } else if (check != NULL && strcmp(request.method, "GET") != 0) {
                free(end_of_request_line);
                free(request_line);
                regfree(&regex);
                bad_request(connfd);
            } else {
                free(end_of_request_line);
                free(request_line);
                regfree(&regex);
                parse_header(buf, connfd);
            }
        }
    }
}

void find_end_of_request(
    char *buf, int connfd) { //finds the end of the request, aswell as the start of message body
    char *expr = "\r\n\r\n";
    regex_t regex;
    int result = regcomp(&regex, expr, REG_EXTENDED);
    if (result < 0) {
    }
    char *header_field = calloc(2048, sizeof(char));
    strcpy(header_field, buf);
    regmatch_t found[1];
    result = regexec(&regex, header_field, 1, found, 0);
    if (result == REG_NOMATCH) {
        free(header_field);
        regfree(&regex);
        bad_request(connfd);
    } else {
        int end = found[0].rm_eo;
        request.start_of_message_body = header_field + end;
        printf("Start of message body :%s\n", request.start_of_message_body);
        free(header_field);
        regfree(&regex);
    }
    printf("hello\n");
}
void parse_header(char *buf, int connfd) { //parses the headers to make sure they are all valid
    char *expr = "[a-zA-Z-]*: [a-zA-Z0-9:./*]*\r\n";
    regex_t regex;
    regcomp(&regex, expr, REG_EXTENDED);

    char *header_field = buf;
    regmatch_t found[100];
    char *header = calloc(2048, sizeof(char));

    int offset = 0;
    int second_result = 0;
    for (int i = 0; i < 100;
         i++) { //Citing Ian Mackinnon for giving me an idea of how to be looping regex matching.
        if ((second_result = regexec(&regex, header_field, 100, found, 0))) {
            if (second_result == REG_NOMATCH) {
                break;
            }
        }
        for (int j = 0; j < 100; j++) {
            if (found[j].rm_so == -1) {
                break;
            }
            if (j == 0) {
                offset = found[j].rm_eo;
            }
            snprintf(header, (found[j].rm_so + found[j].rm_eo), "%.*s",
                found[j].rm_eo - found[j].rm_so, header_field + found[j].rm_so);
            if (strstr(header, "Content-Length: ") != NULL) {
                strcpy(request.header_field, header);
            }
            header_field += offset;
        }
    }
    regfree(&regex);
    free(header);
    if (strstr(buf, "\r\n\r\n") != NULL) {

        find_end_of_request(buf, connfd);
    }
    if (strstr(buf, ":") == NULL) {
        printf("bad\n");
        bad_request(connfd);
    } else {
        check_request(connfd, buf, request);
    }
}
