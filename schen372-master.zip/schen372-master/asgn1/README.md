***#Files***

1. HTTPServer.c - Starter code provided by Doctor Quinn
2. Request.h - Holds the request struct, aswell as the request functions defined in request.c
2. Request.c - This file parses the request and checks if it is valid, and then which method it is going to be used
3. Response.h - Holds the response struct, aswell as the response functions defined in response.c
4. Response.c - This file handles the response that is sent to the client, such as 200 OK, 404 Not Found, 400 Bad Request
5. Makefile - Builds the executable to run this program

***Data Structures***
For this assignment, I only used a buffer, which is essentially just a character array, aswell as structs.
The buffer holds the bytes that are read from connfd, which is were the request is being sent from. The buffer
data structure also holds the response that is sent to the client. 

***Usage***
1. Type `make` or `make all` or `make httpserver` in terminal
2. Type `./httpserver <port-#> in one terminal to open up a server to listening for a client's request
3. In another terminal type `printf "<method> <uri> <HTTP/#.#>\r\n<header fields>\r\n\r\n | nc localhost <port that you specified for the server>`
4. If you want to stop listening for client type `CTRL + C`
5. If you want to delete any executables,objects type `make clean`

***High Level Approach of the Program***
The program first creates a connection and listens for a socket and if a request is sent from the socket, then 2048 bytes
will be read from the socket, and then the parse_request function will be called which checks if the method,uri, or version is 
correct, and if the header fields exist for a PUT or and APPEND. Then the function parse_header is called which checks if all 
the headers that the socket provided are valid. Then the function check_request is called which checks which method is to be used.
After finding out which method to be used, GET will print the file contents, aswell as the size of the file, PUT will put the 
message you want into a file, or a file into another file. APPEND does not work as it should. Then the server closes the socket.


***Design of the program***
Originally, what I wanted to do to handle the request line was use sscanf, but after getting exposed to
regex in Eugene's section. I rewrote my whole design of this program with top-down modularity and it
 it really made my program enforce the robustness principle on methods,uris, and versions, aswell as easier
 to do after each step was complete. This assignment was really diffcult in my opnion, it was hands down the most time I've ever spent on this assignment.
Originally, I was implementing my GET wrong, and hard coding the content-length of each file to only have 2 bytes, which
was obviously wrong. Then I was implementing my PUT request wrong, with a non-existent read, which didn't allow put requests
using curl to work. My APPEND is not working as planned. 

1. Request.c

***parse_request() function***
This function checks if the method,uri,verison are present. If not then the function will return the
400 bad request response to the client. This function then checks if HTTP/1.1 is valid, if not then it will
return the 400 bad request response to the client. Then this function checks if it the method is GET or not and if there
are no header fields. If the method isnt GET, and there are no header_fields then it will return
the 400 bad request response to the client. If everything is valid then the method,uri,version will
be stored in their respective variable in the http_Request request struct.

***find_end_of_request() function***
This functipon checks for the end of the request line (\r\n\r\n), and if it isn't present then
it will return the 400 bad request response to the client. This function also provides the
pointer to which the message body begins.

***parse_header() function***
This function checks if the headers are valid using regex. It will loop to check every potential match in
the request line, if Content-Length is found then it will be stored in the http_Request request struct.
This function calls check_request to see which method is going to used.


2. Response.c

***write_all() function***
This function was provided by Eugene during his TA section. This function will write all
nbytes to the client.

***check_request() function***
This function checks which method is used, whether that would be GET,APPEND,or PUT.
If the method is neither of those then it will return a 501 not impleneted to the client.

***get_request() function***
This function checks if the file is a directory,no permissions to a file, and if it doesn't exist
and will return the respective response to the client. This function will then loop a read to
write all a file's data to the client.

***put_request() function***
This function will check if a file is a directory, and if it is then it will return a 403 forbidden
code to the client. If the file isn't existing already, then it will be created, and the specified amount
of bytes of message body will be put into that file and the 201 created response will be sent back to the client.
If the file exists, then the  200 Ok response will be sent to the client.

***append_request()function***
This function does the same thing as put, without the O_CREAT, and O_TRUNC flag, but it does not work.

***bad_request() function***
This function prints out  400 bad request to the socket.

***not_implented() function***
This function prints out 501 not implemented to the socket

***not_found() function***
This function prints 404 not found to the socket

***forbiden() function***
This function prints 403 forbbiden to the socket.

***created() function***
This function prints 201 created to the socket.

***get_ok() function***
This function prints out 200 Ok aswell as the Content-Length: <file size> to the socket, and the file contents.

***ok() function***
This function prints out 200 Ok to the socket.


***Errors that I handle***

files that don't exist
zero-length files
directories
permission denied
missing header fields

***References***
I am citing Ian Mackinnon for his example of how to loop a regex matching.
https://gist.github.com/ianmackinnon/3294587
This was really helpful in figuring out how to loop regex.
