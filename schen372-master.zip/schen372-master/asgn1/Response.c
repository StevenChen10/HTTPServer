#include <regex.h>
#include <assert.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/stat.h>
#include "Response.h"
#include "Request.h"

struct Response http_response;
struct stat file_stat;

ssize_t write_all(int connfd, char buf[], size_t nbytes) {
    size_t total = 0; //track the total amount of bytes written
    size_t bytes = 0; //tracks the bytes written from a single write() call
    do {
        bytes = write(connfd, buf + total, nbytes - total);
        if (bytes < 0) {
            return -1;
        }
        total += bytes;
    } while (total < nbytes);
    return total;
}

void check_request(int connfd, char *buf,
    struct HTTP_Request
        request) { //checks for which method to be used, or if isn't a supported request.
    printf("dead 0\n");
    printf("req method: %s\n", request.method);
    int is_get = strcmp(request.method, "GET");
    int is_put = strcmp(request.method, "PUT");
    int is_append = strcmp(request.method, "APPEND");
    if ((strstr(request.version, "HTTP/1.1")) == NULL) {
        bad_request(connfd);
    } else if (is_get != 0 && is_put != 0 && is_append != 0) {
        printf("dead 1\n");
        not_implemented(connfd);
    } else if (is_get == 0) {
        printf("dead 2\n");
        get_request(connfd, request);
    } else if (is_put == 0) {
        printf("dead 3\n");
        put_request(connfd, buf, request);
    } else if (is_append == 0) {
        append_request(connfd, buf, request);
    }
    printf("end of check request\n");
}

void get_request(int connfd, struct HTTP_Request request) { //handles all the work for GET request
    char *file_name = request.uri;
    file_name++;
    printf("File: %s\n", file_name);
    int fd = 0;
    int rd;
    char file_buf[4096];
    memset(file_buf, '\0', sizeof(file_buf));
    printf("File name: %s\n", file_name);
    printf("File descriptor: %d\n", O_RDONLY);
    printf("CONNFD: %d\n", connfd);
    fd = open(file_name, O_RDONLY);
    fstat(fd, &file_stat);
    if (S_ISDIR(file_stat.st_mode)) {
        forbidden(connfd);
    } else if (fd == -1) {
        fd = open(file_name, O_RDONLY);
        if (errno == 13) {
            forbidden(connfd);
        } else if (errno == 2) {
            not_found(connfd);
            printf("request.status_code :%d\n", http_response.status_code);
        } else if (errno == 9) {
            not_found(connfd);
            printf("request.status_code :%d\n", http_response.status_code);
        }
    } else {
        int file_bytes = file_stat.st_size;
        get_ok(connfd, file_bytes);
        while ((rd = read(fd, file_buf, sizeof(file_buf))) > 0) {
            write_all(connfd, file_buf, rd);
        }
        close(fd);
    }
}

// void put_request(
//     int connfd, char *buf, struct HTTP_Request request) { //handles all the work for a put request
//     char write_buf[2048];
//     memset(write_buf, '\0', sizeof(write_buf));
//     if (strstr(request.header_field, "Content-Length: ") == NULL) {
//         bad_request(connfd);
//     }
//     char *file_name = request.uri;
//     file_name++;
//     int fd = 0;
//     int rd;
//     char file_buf[4096];
//     char *token = strtok(request.header_field, " ");
//     token = strtok(NULL, request.header_field);
//     char str[40];
//     strcpy(str, token);

//     char *ptr;
//     request.bytes = strtol(str, &ptr, 10);
//     printf("uri: %s\n", request.uri);
//     printf("request bytes: %d\n", request.bytes);
//     fstat(fd, &file_stat);
//     fd = open(file_name, O_WRONLY | O_TRUNC);
//     if (S_ISDIR(file_stat.st_mode)) {
//         forbidden(connfd);
//     } else if (errno == 13) {
//         forbidden(connfd);
//     } else if (fd == -1) {
//         fd = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
//         ssize_t total = 0;
//         printf("stuck here\n");
//         printf("buffer contents: %s\n", buf);
//         while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) > 0) {
//             printf("file buf contents: %s\n", file_buf);
//             printf("bytes read : %d\n", rd);
//             ssize_t bytes_write = 0;
//             printf("stuck here 1\n");
//             // bytes_write = write(fd, request.start_of_message_body, request.bytes);
//             total += bytes_write;
//             bytes_write = write(fd, file_buf + bytes_write, rd - bytes_write);
//             printf("stuck here 2\n");
//             total += bytes_write;
//         }
//         while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) == 0) {
//             printf("file buf contents: %s\n", file_buf);
//             printf("bytes read : %d\n", rd);
//             ssize_t bytes_write = 0;
//             printf("stuck here 3\n");
//             bytes_write = write(fd, request.start_of_message_body, request.bytes);
//             printf("bytes wrote 1: %zd\n", bytes_write);
//             total += bytes_write;
//             printf("bytes wrote 2: %zd\n", bytes_write);
//         }
//         printf("hereasdlksalkdos;alkdl;sa\n");
//         created(connfd);
//     } else {
//         // ok(connfd);
//         ssize_t total = 0;
//         size_t bytes_write = 0; //bufer size is 1k , message body is 4k , content length is 3k
//         printf("stuck here\n");
//         printf("buffer contents: %s\n", buf);

//         int length = strlen(request.start_of_message_body);
//         if (request.bytes > length) {
//             bytes_write = write_all(fd, request.start_of_message_body, length - 2);
//             total += bytes_write;
//         } else {
//             bytes_write = write_all(fd, request.start_of_message_body, request.bytes);
//             total += bytes_write;
//         }
//         ssize_t total_bytes_read = 0;
//         unsigned int total_bytes_written = 0;
//         while ((rd = read(connfd, file_buf, 4096)) > 0) {
//             printf("file buf contents: %s\n", file_buf);
//             printf("bytes read : %d\n", rd);
//             total_bytes_read += rd;
//             printf("total: %zd\n", total_bytes_read);
//             if (request.bytes < total_bytes_read) {
//                 bytes_write = write(
//                     fd, file_buf + total_bytes_written, request.bytes - total_bytes_written);
//                 printf("i wrote 1k\n");
//                 break;
//             } else if (request.bytes > total_bytes_read) {
//                 bytes_write = write(fd, file_buf + total_bytes_written, rd);
//                 printf("writing bytes: %zu\n", bytes_write);
//                 printf("i wrote 1.5k\n");
//                 total_bytes_written += bytes_write;
//             } else {
//                 bytes_write = write(
//                     fd, file_buf + total_bytes_written, request.bytes - total_bytes_written);
//                 break;
//             }
//         }
//         ok(connfd);
//     }
//     printf("hello bye goodbye\n");
// }

void put_request(
    int connfd, char *buf, struct HTTP_Request request) { //handles all the work for a put request
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    if (strstr(request.header_field, "Content-Length: ") == NULL) {
        bad_request(connfd);
    }
    char *file_name = request.uri;
    file_name++;
    int fd = 0;
    int rd;
    char file_buf[4096];
    char *token = strtok(request.header_field, " ");
    token = strtok(NULL, request.header_field);
    char str[40];
    strcpy(str, token);

    char *ptr;
    request.bytes = strtol(str, &ptr, 10);
    printf("uri: %s\n", request.uri);
    printf("buf contents %s\n", buf);
    printf("request bytes: %d\n", request.bytes);
    fstat(fd, &file_stat);
    fd = open(file_name, O_WRONLY | O_TRUNC);
    if (S_ISDIR(file_stat.st_mode)) {
        forbidden(connfd);
    } else if (fd == -1) {
        fd = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (errno == 21) {
            forbidden(connfd);
        } else if (errno == 13) {
            forbidden(connfd);
        } else {
            ssize_t total = 0;
            while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) > 0) {
                ssize_t bytes_write = 0;
                // bytes_write = write(fd, request.start_of_message_body, request.bytes);
                total += bytes_write;
                bytes_write = write(fd, file_buf + bytes_write, rd - bytes_write);
                total += bytes_write;
            }
            while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) == 0) {
                ssize_t bytes_write = 0;
                bytes_write = write(fd, request.start_of_message_body, request.bytes);
                total += bytes_write;
            }
            created(connfd);
        }
    } else {
        // ok(connfd);
        ssize_t total = 0;
        while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) > 0) {
            ssize_t bytes_write = 0;
            bytes_write = write_all(fd, file_buf + bytes_write, rd - bytes_write);
            total += bytes_write;
        }
        while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) == 0) {
            ssize_t bytes_write = 0;
            bytes_write = write_all(fd, request.start_of_message_body, request.bytes);
            total += bytes_write;
        }
        ok(connfd);
    }
}

void append_request(int connfd, char *buf,
    struct HTTP_Request request) { //handles all the work for an append request
    char write_buf[2048];
    printf("buf contents %s\n", buf);
    memset(write_buf, '\0', sizeof(write_buf));
    if (strstr(request.header_field, "Content-Length: ") == NULL) {
        bad_request(connfd);
    }
    char *file_name = request.uri;
    file_name++;
    int fd = 0;
    int rd;
    char file_buf[4096];
    char *token = strtok(request.header_field, " ");
    token = strtok(NULL, request.header_field);
    request.bytes = atoi(token);
    fd = open(file_name, O_WRONLY | O_APPEND);
    printf("fd %d\n", fd);
    if (fd == -1) {
        if (errno == 21) {
            forbidden(connfd);
        } else if (errno == 13) {
            forbidden(connfd);
        } else if (errno == 21) {
            forbidden(connfd);
        } else if (errno == 2) {
            not_found(connfd);
        }
    } else {
        ssize_t total = 0;
        while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) > 0) {
            ssize_t bytes_write = 0;
            bytes_write = write(fd, file_buf + bytes_write, rd - bytes_write);
            total += bytes_write;
        }
        while (total < request.bytes && (rd = read(connfd, file_buf, 4096)) == 0) {
            ssize_t bytes_write = 0;
            bytes_write = write(fd, request.start_of_message_body, request.bytes);
            total += bytes_write;
        }
        ok(connfd);
    }
}

void bad_request(int connfd) { //print bad request to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 400;
    http_response.status_phrase = "Bad Request";
    snprintf(
        http_response.header_field, sizeof(http_response.header_field), "Content-Length: %s", "12");
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n%s\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field,
        http_response.message_body);
    write_all(connfd, write_buf, 60);
    memset(write_buf, '\0', sizeof(write_buf));
}

void not_implemented(int connfd) { //print not implemented to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 501;
    http_response.status_phrase = "Not Implemented";
    snprintf(
        http_response.header_field, sizeof(http_response.header_field), "Content-Length: %s", "16");
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n%s\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field,
        http_response.message_body);
    write_all(connfd, write_buf, 68);
    memset(write_buf, '\0', sizeof(write_buf));
}

void not_found(int connfd) { //print not found to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 404;
    http_response.status_phrase = "Not Found";
    snprintf(http_response.header_field, sizeof(http_response.header_field),
        "Content-Length: %s\r\n\r\n", "10");
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s%s\n", http_response.status_code,
        http_response.status_phrase, http_response.header_field, http_response.message_body);
    write_all(connfd, write_buf, 56);
    memset(write_buf, '\0', sizeof(write_buf));
}

void forbidden(int connfd) { //print forbidden to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 403;
    http_response.status_phrase = "Forbidden";
    snprintf(http_response.header_field, sizeof(write_buf), "Content-Length: %s\r\n\r\n", "10");
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s%s\n", http_response.status_code,
        http_response.status_phrase, http_response.header_field, http_response.message_body);
    write_all(connfd, write_buf, 56);
    memset(write_buf, '\0', sizeof(write_buf));
}

void created(int connfd) { //print created to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 201;
    http_response.status_phrase = "Created";
    snprintf(http_response.header_field, sizeof(write_buf), "Content-Length: %s", "8");
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n%s\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field,
        http_response.message_body);
    write_all(connfd, write_buf, 51);
    memset(write_buf, '\0', sizeof(write_buf));
}

void get_ok(int connfd, int file_bytes) { //print GET's 200 ok to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 200;
    int size = 0;
    http_response.status_phrase = "OK";
    snprintf(http_response.header_field, sizeof(write_buf), "Content-Length: %d", file_bytes);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field);
    size = strlen(write_buf);
    printf("hello: %d\n", size);
    write_all(connfd, write_buf, size);
    memset(write_buf, '\0', sizeof(write_buf));
}

void ok(int connfd) { //print normal 200 ok to socket
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 200;
    http_response.status_phrase = "OK";
    snprintf(http_response.header_field, sizeof(write_buf), "Content-Length: %d", 3);
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n%s\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field,
        http_response.message_body);
    write_all(connfd, write_buf, 41);
    memset(write_buf, '\0', sizeof(write_buf));
}

void internal_server_error(int connfd) {
    char write_buf[2048];
    memset(write_buf, '\0', sizeof(write_buf));
    http_response.status_code = 500;
    http_response.status_phrase = "Internal Servor Error";
    strcpy(http_response.message_body, http_response.status_phrase);
    snprintf(write_buf, sizeof(write_buf), "HTTP/1.1 %d %s\r\n%s\r\n\r\n%s\n",
        http_response.status_code, http_response.status_phrase, http_response.header_field,
        http_response.message_body);
    write_all(connfd, write_buf, 70);
    memset(write_buf, '\0', sizeof(write_buf));
}
