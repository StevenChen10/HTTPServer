#pragma once
#include <stdbool.h>

typedef struct {
    int size;
    int head;
    int tail;
    int *buffer;
    int capacity;
} BoundedQueue;

BoundedQueue queue_new(int capacity);

void enqueue(BoundedQueue *q, int x);

int dequeue(BoundedQueue *q, int *x);

bool queue_full(BoundedQueue *q);

bool queue_empty(BoundedQueue *q);

void queue_print(BoundedQueue *q);
