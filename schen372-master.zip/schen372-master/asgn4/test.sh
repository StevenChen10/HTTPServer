# default threads test

for i in {1..250};
do
    printf "PUT /baz.txt HTTP/1.1\r\nContent-Length: 8500\r\nRequest-Id: $i\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus nulla, luctus eget semper sed, placerat ultrices ante. Nullam mattis tempor urna, non interdum risus blandit accumsan. Curabitur lobortis eu felis vitae pharetra. Suspendisse nisl ligula, hendrerit non ultricies nec, vulputate quis lacus. Nullam tincidunt nisl tempor neque luctus, id imperdiet tortor porta. Sed eleifend viverra eros, ut congue dui commodo eu. Sed laoreet semper felis bibendum tempus. Pellentesque laoreet magna quam, dapibus laoreet quam tincidunt ut. Duis sollicitudin mauris rutrum, maximus turpis ut, sagittis ex. Cras porta, velit molestie efficitur sollicitudin, nisl dui porta purus, id tincidunt lorem ligula eget nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in pharetra enim.

Morbi quam nibh, dictum quis turpis eget, aliquet tincidunt justo. Donec facilisis gravida lectus. Aenean tellus odio, vulputate ut feugiat non, rhoncus venenatis magna. Nam eleifend at turpis in convallis. Sed sit amet tortor at lectus dapibus pharetra. Nulla eget elit euismod, auctor ligula at, rutrum massa. Proin mollis, augue vitae facilisis iaculis, velit neque vestibulum orci, ut elementum magna leo non turpis. Duis in eleifend leo. Fusce ut fringilla mi. Etiam commodo purus vitae urna consectetur congue. In lorem nibh, convallis scelerisque ex sollicitudin, aliquam bibendum orci. Morbi lacus dolor, pretium ut lacinia sit amet, dignissim id ligula.

Vivamus ornare venenatis orci in volutpat. Nunc aliquet sapien purus, a mattis velit convallis sit amet. Integer consectetur lobortis sem, in ultricies mi pharetra id. Quisque pulvinar tortor id lorem elementum, sed vehicula est congue. Praesent lacus nisi, vestibulum et tristique sed, semper non odio. Vestibulum tempor dictum scelerisque. Nunc feugiat consequat suscipit. Mauris eleifend, erat sed finibus pulvinar, turpis metus bibendum elit, ac laoreet turpis massa et dolor. Suspendisse cursus est est. Sed quis dapibus lectus, at tempus diam. Donec placerat fermentum metus, ac placerat augue tempus ut. Fusce facilisis mi in mi lacinia, non tincidunt mauris tincidunt. Quisque libero odio, iaculis pretium sapien quis, convallis dictum nisi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc lobortis vestibulum augue sed bibendum.

Vivamus nec lorem ut dui interdum aliquet. Etiam imperdiet sem eget leo aliquet, in pellentesque lorem dictum. Pellentesque mauris ante, consectetur in semper ut, fringilla a lorem. Sed lacinia consectetur purus sed euismod. Phasellus luctus nisl non metus egestas, vitae ornare neque ullamcorper. Duis semper placerat ipsum, commodo fermentum dolor aliquam at. Sed arcu felis, tempor et varius sit amet, sollicitudin eget mi. Aenean vitae ipsum sed nulla tempus euismod sit amet id nisl. Ut dapibus lectus ut ex ultricies, sit amet dictum sapien molestie. Cras et lectus in justo efficitur suscipit at sit amet dui. In dignissim, est at sollicitudin elementum, turpis tortor efficitur mi, ac posuere elit quam sed ex. In ac dictum lectus. Maecenas ultricies orci leo, a posuere odio congue nec. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.

Fusce nec blandit leo. Duis ac sollicitudin lacus. Pellentesque fringilla lobortis tincidunt. Aenean enim odio, porttitor sed egestas non, laoreet a orci. Donec tempus hendrerit sapien, eu suscipit orci. Suspendisse vitae dui vitae nunc ullamcorper viverra non nec lorem. Etiam mattis, elit ut bibendum hendrerit, dui elit auctor felis, sit amet scelerisque massa ligula dignissim nulla.

Cras interdum aliquam eros, venenatis sollicitudin libero condimentum id. Cras risus est, sagittis eu facilisis quis, malesuada vitae nisl. Nullam nec tellus nec urna suscipit cursus. Aenean scelerisque ornare metus, vitae fermentum leo eleifend et. Sed consequat lectus sit amet tellus mollis, at dignissim libero dignissim. Nulla nec erat a orci fringilla vehicula. Cras erat lorem, cursus vel mattis a, ultricies vitae neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus quis ante ac sem commodo interdum eu id erat. Vestibulum pharetra, tortor in pretium porta, urna lorem dignissim turpis, sagittis lacinia velit risus id nibh.

Pellentesque id lobortis lacus. Nullam vel risus sollicitudin nibh dictum tempor eu a neque. Maecenas tristique facilisis nisl. Donec egestas enim eros, ac sollicitudin metus ultricies quis. Fusce a euismod lectus. Nulla eu sodales felis. Sed hendrerit congue ex, et porttitor massa facilisis at.

Donec ac sagittis orci. Pellentesque sed sapien eget arcu luctus tincidunt. Donec congue ullamcorper metus, ut tincidunt leo efficitur facilisis. Integer porta enim quis lorem luctus fermentum. Phasellus in erat at est pretium volutpat at sagittis dolor. Proin commodo mattis mattis. Curabitur pulvinar leo id enim pulvinar pellentesque. Etiam semper nulla quis leo vestibulum posuere. Fusce in accumsan arcu. Ut lorem arcu, auctor non hendrerit eu, varius in leo. In hac habitasse platea dictumst. In hac habitasse platea dictumst. Ut non lacinia sapien, sit amet congue libero. Praesent mollis odio sed ex vehicula sollicitudin. Curabitur metus ligula, condimentum non porttitor semper, fermentum nec quam.

Mauris vestibulum, felis nec porttitor porttitor, nulla magna mattis purus, facilisis consequat nibh dolor quis lacus. Sed leo ligula, ornare vitae porta vel, sodales a enim. Pellentesque bibendum elit nec tortor faucibus luctus nec quis sapien. Phasellus posuere odio purus, eu maximus nibh ultrices nec. Nunc eu convallis leo. Vestibulum ut est non quam volutpat tincidunt. Curabitur fermentum eleifend mi ac commodo. Aenean aliquet diam nec massa pellentesque, ut luctus metus vehicula. Proin vulputate feugiat eros, sed accumsan diam suscipit non. Aenean eleifend leo libero, nec faucibus magna vehicula ut. Nam nisi sem, fringilla ac posuere viverra, congue ut nibh. Vestibulum tincidunt finibus risus in vestibulum. Morbi luctus dignissim libero vel aliquam. Ut in purus nisi. Proin euismod mauris auctor, tristique arcu at, lobortis augue.

Pellentesque condimentum, lacus quis aliquam sodales, lacus est convallis ligula, a ultricies risus libero eget magna. Etiam dictum erat massa, at dignissim felis commodo nec. Praesent auctor, odio vel convallis molestie, orci elit imperdiet eros, quis lacinia nisi mauris in metus. Sed vel dapibus est. Aenean auctor dui vitae diam ultricies, id malesuada ligula cursus. Duis suscipit viverra lorem sed pellentesque. Vestibulum congue nibh vitae est iaculis tempor.

Nullam fermentum ipsum eget diam fringilla, eget tincidunt eros gravida. Cras condimentum dictum sapien sed pulvinar. Nunc dignissim leo at lacus semper auctor. Pellentesque semper ultrices tellus nec tincidunt. Aliquam fermentum purus vel erat porttitor, ut molestie velit convallis. Nulla sed laoreet quam. Praesent ac scelerisque enim, mattis posuere eros. Pellentesque tristique est nec imperdiet dapibus. Donec vel justo dictum, pharetra lacus at, interdum augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Suspendisse consequat dui ac tortor condimentum, ac tincidunt leo pulvinar. Vestibulum placerat lacus et lectus pellentesque aliquam.

Suspendisse potenti. Cras hendrerit vehicula quam. Fusce vitae ullamcorper nulla, quis sollicitudin lorem. Integer euismod egestas enim, sit amet convallis ligula convallis condimentum. Sed gravida ullamcorper tempor. Morbi dictum rhoncus metus, vel dictum est pulvinar hendrerit. Aenean mi erat, iaculis eu scelerisque et, volutpat quis nibh. Proin sed blandit lacus, et ultrices dolor. Nunc suscipit non nulla sit amet vestibulum. Etiam condimentum neque ut massa semper, vel ornare dui tincidunt. Duis lacus dui, finibus hendrerit diam at, sollicitudin rhoncus nisl. Morbi vel sapien aliquet tellus molestie maximus. Nulla et pharetra odio, faucibus interdum magna. Nulla vel. \r\n <thizz the end>" | nc -N localhost 6970
done


for i in {1..250};
do
    printf "GET /baz.txt HTTP/1.1\r\nRequest-Id: $i\r\n\r\n" | nc -N localhost 6970
    

done

for i in {1..250};
do
    printf "APPEND /bar.txt HTTP/1.1\r\nContent-Length: 30\r\nRequest-Id: $i\r\n\r\nTest your mother $i\r\n" | nc -N localhost 6970
    

done

for i in {1..250};
do
    printf "GET /foo.txt HTTP/1.1\r\nRequest-Id: $i\r\n\r\n" | nc -N localhost 6970
    

done
