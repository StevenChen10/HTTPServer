***FILE DESCRIPTION***
1. httpserver_asgn2.c - This file is starter code that was provided by Dr.Quinn. It help's parse inputs, aswell as audit log.
2. Request.c - This file parses the headers aswell as parse the request line. 
3. Response.c This file sends the correct respective response to connfd such as 200 OK, 201 Created, 404 Not Found

***How To Ensure Durability***
In this assignment, every time a request is sent it's logged in a logfile, and then its flushed to make sure the buffer is empty 
upon every new request.


***Program Design***
This program is built off of my assignment1 which I was able to get patched up before starting this assignment. Understanding the
starter code was sort of a challenge, but after figuring out what it was doing made it very easy to audit log. Since, the request,
and response was stored in a struct, it was fairly simple to find out where things that were sent were stored. At first my code
was sending an audit log for content-less requests which didn't make sense, so a easy fix was to check if the buffer that read 
bytes had any thing stored in it. If it did, then the log macro would print to stderr, and then fflush the buffer. If not, then
nothing happens.


***High Level Approach***
First off, the program creates a socket that listens for a conenction, and then when the client sends a request to that connection
the server will read from that request until it sees a "\r\n\r\n" which indicates the end of the request line. Then, the program
will parse the request-line, into the method, URI, and the version of HTTP that is being used. The next step is that it will
parse the headers, and in every iteration of the loop it will check if the header is Content-Length: <#>, or Request-Id: <#>.
The next step after this is that it will determine which HTTP method is being used, whether its GET,PUT, or APPEND. Each, method
will do their respective tasks and produce 200 OK, if everything was successful, 404 Not Found if the file doesn't exist (only for GET, APPEND)
or 201 Created if it was PUT Request.



***Data Structures***
In this assignment, I used char arrays(buffer), aswell as the regex arrays to store the indices of each matching.


***Errors Returned***
1. 404 Not Found, if there is no path to the file
2. 500 Internal Server Error, if there is a malloc failure

***Functions***
1. Request.c

***parse_request() function***
This function parses the method,uri,version.

***parse_header() function***
This function checks if the headers are valid using regex. It will loop to check every potential match in
the request line, if Content-Length is found then it will be stored in the http_Request request struct.
If Request-Id is found then it will be stored in the http_request reqeust struct.
This function calls check_request to see which method is going to used.

2. Response.c

***write_all() function***
This function was provided by Eugene during his TA section. This function will write all
nbytes to the client.

***check_request() function***
This function checks which method is used, whether that would be GET,APPEND,or PUT.

***get_request() function***
This function checksif it doesn't exist and will return 404 Not Found if so.
If the file exists, this function will then loop a read to write all a file's data to the client.

***put_request() function***
If the file isn't existing already, then it will be created, and the specified amount
of bytes of message body will be put into that file and the 201 created response will be sent back to the client.
If the file exists, then the  200 Ok response will be sent to the client.


***append_request() function***
If the file does not exist, then 404 Not Found will be returned to the client. If not then, 
this function will open up a file in O_APPEND mode which will write to the end of the file, and
send 200 OK to the client. 

***created() function***
This function prints 201 created to connfd.

***get_ok() function***
This function prints out 200 Ok aswell as the Content-Length: <file size> to connfd and the file contents.

***ok() function***
This function prints out 200 Ok to connfd.

***not_found() function***
This function prints 404 not found to confd.

***internal_server_error()function***
This function prints 500 Internal Server Errror to connfd.
